package Simulador;

public interface Invertible {
	public void girar();
	
}
