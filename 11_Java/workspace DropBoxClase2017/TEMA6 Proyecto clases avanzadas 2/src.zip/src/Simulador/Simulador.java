package Simulador;

public class Simulador {

	public Simulador() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Componente c1 = new Componente();
		Diodo d1 = new Diodo(5,5,5);
		Condensador cnd1 = new Condensador();
		Led l1 = new Led();

		d1.leeDatos();
		System.out.println(d1.getIntensidadMaxima());
		System.out.println(d1.getLongitud());
		System.out.println(d1.getTensionlnversa());
		
		// Polimorfismo
		Componente comp1 = new Diodo();
		Diodo d2 = new Led();
		
		// Para esto pide un cast
		// Led l2 = (Led) new Diodo();
		
	}

}
